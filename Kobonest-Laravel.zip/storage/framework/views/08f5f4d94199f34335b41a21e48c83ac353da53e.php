<ul class="kt-nav">

    <li class="kt-nav__item">
        <a href="<?php echo e(route('admin.users.create')); ?>" class="kt-nav__link">
            <i class="kt-nav__link-icon flaticon2-drop"></i>
            <span class="kt-nav__link-text">Create User</span>
        </a>
    </li>
    
    <li class="kt-nav__item">
        <a href="<?php echo e(route('admin.agents.create')); ?>" class="kt-nav__link">
            <i class="kt-nav__link-icon flaticon2-telegram-logo"></i>
            <span class="kt-nav__link-text">Create Agent</span>
        </a>
    </li>
    <li class="kt-nav__item">
        <a href="<?php echo e(route('admin.saving.category')); ?>" class="kt-nav__link">
            <i class="kt-nav__link-icon flaticon-computer"></i>
            <span class="kt-nav__link-text">Savings Categories</span>
        </a>
    </li>
    <li class="kt-nav__item">
        <a href="<?php echo e(route('admin.deposit.category')); ?>" class="kt-nav__link">
            <i class="kt-nav__link-icon flaticon2-console"></i>
            <span class="kt-nav__link-text"> Investment Deposit Categories</span>
        </a>
    </li>
</ul>
<?php /**PATH C:\MyRecentProjects\Kobonest-Laravel\resources\views/admin/includes/quick-actions.blade.php ENDPATH**/ ?>