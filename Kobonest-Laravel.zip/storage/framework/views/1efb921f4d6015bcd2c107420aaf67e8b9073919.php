<?php $__env->startSection('title', 'Register As An Agent'); ?>

<?php $__env->startSection('content'); ?>

<div class="kt-grid kt-grid--ver kt-grid--root kt-page">
    <div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v4 kt-login--signin" id="kt_login">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" style="background:  linear-gradient(rgba(0, 0, 0, 0.7),rgba(0, 0, 0, 0.7) ),url(<?php echo e(asset('media/bg-2.jpg')); ?>) no-repeat; background-size: cover;">
            <div class="kt-grid__item kt-grid__item--fluid kt-login__wrapper">
                <div class="kt-login__container">
                    <div class="kt-login__logo">
                        <a href="#">
                            <img src="<?php echo e(asset('kobonest_logo.png')); ?>">
                        </a>
                    </div>
                    <div class="kt-login__signin">
                        <div class="kt-login__head">
                            <h3 class="kt-login__title" style="color: white;">Sign Up For An Agent Account</h3>
                        </div>
                        <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button>
                                    
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                        <?php endif; ?>
                        <form class="kt-form" action="<?php echo e(route('agent.post.register')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="">
                                <input class="form-control" type="text" placeholder="Enter First Name" name="first_name" required>
                                <?php if($errors->first('first_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <span class="form-text text-muted"><?php echo e($errors->first('first_name')); ?></span>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="">
                                <input class="form-control" type="text" placeholder="Enter Last Name" name="last_name" required>
                                <?php if($errors->has('last_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <span class="form-text text-muted"><?php echo e($errors->first('last_name')); ?></span>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="">
                                <input class="form-control" type="text" placeholder="Enter Phone Number" name="phone_number" autocomplete="off" required>
                                <?php if($errors->has('phone_number')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <span class="form-text text-muted"><?php echo e($errors->first('phone_number')); ?></span>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="">
                                <input class="form-control" type="text" placeholder="Enter Email Address" name="email" autocomplete="off" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <span class="form-text text-muted"><?php echo e($errors->first('email')); ?></span>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="">
                                <input class="form-control" type="password" placeholder="Enter Password" name="password" required minlength="8">
                                    <span class="invalid-feedback" role="alert">
                                        <span class="form-text text-muted"><?php echo e($errors->first('password')); ?></span>
                                    </span>
                            </div>
                            <div class="">
                                <input class="form-control" type="password" placeholder="Confirm Password" name="password_confirmation" required>
                            </div>
                            <div class="row kt-login__extra">
                                <div class="col kt-align-left">
                                    <label class="kt-checkbox">
                                        <input type="checkbox" name="agree" required>I Agree the <a href="#" class="kt-link kt-login__link kt-font-bold">terms and conditions</a>.
                                        <span></span>
                                    </label>
                                    <span class="form-text text-muted"></span>
                                </div>
                            </div>
                            <div class="kt-login__actions">
                                <button class="btn btn-brand btn-pill kt-login__btn-primary">Sign Up</button>&nbsp;&nbsp;
                                <button id="kt_login_signup_cancel" class="btn btn-secondary btn-pill kt-login__btn-secondary">Cancel</button>
                            </div>
                        </form>
                    </div>
                    <div class="kt-login__account">
                        <span class="kt-login__account-msg">
                            Already have an account?
                        </span>
                        &nbsp;&nbsp;
                        <a href="<?php echo e(route('agent.login')); ?>"  class="kt-login__account-link">Sign In!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyRecentProjects\Kobonest-Laravel\resources\views/agent/auth/register.blade.php ENDPATH**/ ?>