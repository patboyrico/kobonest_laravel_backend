<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgentSetting extends Model
{
    //
}
